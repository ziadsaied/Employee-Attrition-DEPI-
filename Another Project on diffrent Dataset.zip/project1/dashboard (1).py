import streamlit as st
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# -------------------- Page Settings --------------------
st.set_page_config(page_title="Employee Attrition Dashboard", layout="wide")

# -------------------- Custom CSS --------------------
st.markdown("""
    <style>
    body {
        background-color: #121212;
        color: #f5f5f5;
    }
    .main {
        background-color: #1e1e1e;
        padding: 20px;
        border-radius: 12px;
    }
    h1, h2, h3, h4 {
        color: #00BFFF;
        font-weight: 600;
    }
    .stMetric {
        background: #262730;
        color: white;
        padding: 15px;
        border-radius: 15px;
        box-shadow: 0px 4px 12px rgba(0,0,0,0.5);
    }
    </style>
""", unsafe_allow_html=True)

# -------------------- Load and Clean Data --------------------
df = pd.read_csv("employee_attrition_dataset 2.csv")
df = df.drop(["EmployeeCount", "StandardHours", "Over18", "EmployeeNumber"], axis=1)
df["Attrition"] = df["Attrition"].map({"Yes": 1, "No": 0})

# -------------------- Sidebar Filters --------------------
st.sidebar.header("⚙️ Filters")

department_filter = st.sidebar.multiselect("Select Department:", df["Department"].unique(), default=df["Department"].unique())
gender_filter = st.sidebar.multiselect("Select Gender:", df["Gender"].unique(), default=df["Gender"].unique())
overtime_filter = st.sidebar.multiselect("Select OverTime:", df["OverTime"].unique(), default=df["OverTime"].unique())

df_filtered = df[
    (df["Department"].isin(department_filter)) &
    (df["Gender"].isin(gender_filter)) &
    (df["OverTime"].isin(overtime_filter))
]

# -------------------- KPIs --------------------
st.title("📊 Employee Attrition Dashboard")

col1, col2, col3, col4, col5 = st.columns(5)
with col1:
    st.metric("👥 Employees", df_filtered.shape[0])
with col2:
    st.metric("📉 Attrition Rate", f"{df_filtered['Attrition'].mean()*100:.2f}%")
with col3:
    st.metric("📊 Columns", df_filtered.shape[1])
with col4:
    st.metric("💰 Avg. Income (Leavers)", f"{df_filtered[df_filtered['Attrition']==1]['MonthlyIncome'].mean():.0f}")
with col5:
    st.metric("🎂 Avg. Age (Leavers)", f"{df_filtered[df_filtered['Attrition']==1]['Age'].mean():.1f}")

st.markdown("---")

# -------------------- Tabs --------------------
tab1, tab2, tab3, tab4 = st.tabs(["🎯 Attrition", "🏷️ Categorical", "📈 Numerical", "🔗 Correlation"])

# Attrition
with tab1:
    st.subheader("Attrition Distribution")
    fig, ax = plt.subplots(figsize=(4,2.5))
    sns.set_style("darkgrid")
    sns.countplot(x="Attrition", data=df_filtered, palette="coolwarm", ax=ax)
    ax.set_xticklabels(["No", "Yes"], fontsize=9)
    st.pyplot(fig)

# Categorical
with tab2:
    st.subheader("Categorical Analysis")
    cat_col = st.selectbox("Select Categorical Column:", ["Department", "Gender", "OverTime", "BusinessTravel", "JobRole", "MaritalStatus"])
    fig2, ax2 = plt.subplots(figsize=(5,2.5))
    sns.countplot(x=cat_col, hue="Attrition", data=df_filtered, palette="coolwarm", ax=ax2)
    plt.xticks(rotation=30, fontsize=8)
    st.pyplot(fig2)

# Numerical
with tab3:
    st.subheader("Numerical Analysis")
    num_col = st.selectbox("Select Numerical Column:", ["Age", "MonthlyIncome", "YearsAtCompany", "DistanceFromHome"])
    fig3, ax3 = plt.subplots(figsize=(5,2.5))
    sns.boxplot(x="Attrition", y=num_col, data=df_filtered, palette="coolwarm", ax=ax3)
    ax3.set_ylabel(num_col, fontsize=9)
    st.pyplot(fig3)

# Correlation
with tab4:
    st.subheader("Correlation Heatmap")
    fig4, ax4 = plt.subplots(figsize=(7,4))
    corr = df_filtered.select_dtypes(include=["int64","float64"]).corr()
    sns.heatmap(corr, cmap="coolwarm", center=0, annot=True, fmt=".2f", ax=ax4, cbar_kws={"shrink": 0.6})
    st.pyplot(fig4)

# -------------------- Footer --------------------
st.markdown("""
---
✨ This Dashboard was designed in **Professional Dark Mode** using **Streamlit** and **Seaborn**.  
""")
