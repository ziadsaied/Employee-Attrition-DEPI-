import streamlit as st
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# -------------------- Page Settings --------------------
st.set_page_config(page_title="HR Analytics Dashboard (Milestone 2)", layout="wide")

# -------------------- Custom CSS --------------------
st.markdown("""
    <style>
    body {background-color: #f4f4f9;}
    .main {background-color: #ffffff; padding: 20px; border-radius: 10px;}
    h1, h2, h3 {color: #2c3e50;}
    
    /* Metric Box Styling */
    .stMetric {
        background-color: #e3f2fd; /* Changed background color to Light Blue */
        padding: 15px;
        border-radius: 10px;
        text-align: center;
        border: 1px solid #b3e5fc; /* Light border for better visibility */
        box-shadow: 2px 2px 5px rgba(0,0,0,0.1); /* Soft shadow effect */
    }
    
    /* Label (Title) Styling */
    .stMetric label {
        color: #1565c0 !important; /* Title Color */
    }
    
    /* Value (Number) Styling */
    .stMetric [data-testid="stMetricValue"] {
        color: #0d47a1; /* Value Color */
    }
    </style>
""", unsafe_allow_html=True)

# -------------------- Data Loading & Processing --------------------
@st.cache_data
def load_data():
    # Try loading the processed data from the notebook output
    try:
        df = pd.read_csv("processed_employee_data.csv")
    except FileNotFoundError:
        # Fallback to raw data if processed file isn't found
        df = pd.read_csv("employee_attrition_dataset 2.csv")
        # Basic cleaning if raw data is used
        df = df.drop(["EmployeeCount", "StandardHours", "Over18", "EmployeeNumber"], axis=1, errors='ignore')
        df["Attrition"] = df["Attrition"].map({"Yes": 1, "No": 0}) if df["Attrition"].dtype == 'O' else df["Attrition"]
        df['SalaryBand'] = pd.cut(df['MonthlyIncome'], bins=[0, 5000, 15000, 99999], labels=['Low', 'Medium', 'High'])
    return df

df = load_data()

# -------------------- Sidebar Filters --------------------
st.sidebar.header("⚙️ Dashboard Filters")
dept_filter = st.sidebar.multiselect("Filter by Department", df["Department"].unique(), default=df["Department"].unique())
gender_filter = st.sidebar.multiselect("Filter by Gender", df["Gender"].unique(), default=df["Gender"].unique())

# Apply filters
df_filtered = df[df["Department"].isin(dept_filter) & df["Gender"].isin(gender_filter)]

# -------------------- Header & KPIs --------------------
st.title("📊 HR Analytics & Attrition Dashboard")
st.markdown("### Milestone 2: Advanced Analysis & Feature Engineering")

col1, col2, col3, col4 = st.columns(4)
col1.metric("Total Employees", len(df_filtered))
col2.metric("Attrition Rate", f"{df_filtered['Attrition'].mean()*100:.1f}%")
col3.metric("Avg Salary (Leavers)", f"${df_filtered[df_filtered['Attrition']==1]['MonthlyIncome'].mean():,.0f}")
col4.metric("Avg Years at Company", f"{df_filtered['YearsAtCompany'].mean():.1f} Yrs")

st.markdown("---")

# -------------------- Main Analysis Tabs --------------------
tab1, tab2, tab3 = st.tabs(["🔍 Exploratory Analysis", "📈 Statistical Insights", "🤖 Feature Correlation"])

# --- Tab 1: General EDA ---
with tab1:
    col_a, col_b = st.columns(2)
    
    with col_a:
        st.subheader("Attrition by Salary Band")
        if "SalaryBand" in df_filtered.columns:
            fig1, ax1 = plt.subplots()
            sns.countplot(x="SalaryBand", hue="Attrition", data=df_filtered, palette="coolwarm", ax=ax1)
            st.pyplot(fig1)
            st.caption("Visualizing if employees in lower salary bands are more likely to leave.")
        else:
            st.warning("SalaryBand feature not found. Please run the analysis notebook.")

    with col_b:
        st.subheader("Attrition by Department")
        fig2, ax2 = plt.subplots()
        sns.countplot(y="Department", hue="Attrition", data=df_filtered, palette="viridis", ax=ax2)
        st.pyplot(fig2)

# --- Tab 2: Advanced Stats (Leavers vs Stayers) ---
with tab2:
    st.subheader("Distribution Comparison: Leavers vs. Stayers")
    
    # Dropdown to select numeric feature
    target_col = st.selectbox("Select Feature to Compare Distributions:", 
                              ["Age", "MonthlyIncome", "TotalWorkingYears", "DistanceFromHome", "YearsAtCompany"])
    
    fig3, ax3 = plt.subplots(figsize=(10, 4))
    
    # Plot KDE for Stayers
    sns.kdeplot(df_filtered[df_filtered["Attrition"] == 0][target_col], 
                shade=True, color="green", label="Stayed", ax=ax3)
    
    # Plot KDE for Leavers
    sns.kdeplot(df_filtered[df_filtered["Attrition"] == 1][target_col], 
                shade=True, color="red", label="Left", ax=ax3)
    
    plt.legend()
    st.pyplot(fig3)
    st.caption(f"Comparing the distribution of '{target_col}' for employees who stayed (Green) vs those who left (Red).")

# --- Tab 3: Correlation Matrix ---
with tab3:
    st.subheader("Feature Correlation Heatmap")
    st.markdown("This heatmap shows how strongly different numerical features are related to each other.")
    
    # Select only numeric columns for correlation matrix
    numeric_df = df_filtered.select_dtypes(include=['int64', 'float64'])
    
    fig4, ax4 = plt.subplots(figsize=(10, 8))
    sns.heatmap(numeric_df.corr(), annot=False, cmap="coolwarm", linewidths=0.5, ax=ax4)
    st.pyplot(fig4)

# -------------------- Footer --------------------
st.markdown("---")
st.markdown("**Generated for AI & Data Science Track - Round 2**")