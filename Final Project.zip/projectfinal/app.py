import os
from datetime import datetime

import numpy as np
import pandas as pd
from flask import Flask, render_template, request, jsonify, redirect, url_for

from dashboard.dash_app import init_dashboard
from openai import OpenAI

from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OneHotEncoder
from sklearn.ensemble import RandomForestClassifier

# ================= CONFIG =================

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

DATA_PATH = os.path.join(BASE_DIR, "data", "employee_attrition_dataset.csv")

# لو حبيت تستخدمهم بعدين
MODELS_DIR = os.path.join(BASE_DIR, "models")
MODEL_PATH = os.path.join(MODELS_DIR, "attrition_model.pkl")
BEST_MODEL_PATH = os.path.join(MODELS_DIR, "best_random_forest_model.pkl")
IMPUTER_PATH = os.path.join(MODELS_DIR, "data_imputer.pkl")
ENCODER_PATH = os.path.join(MODELS_DIR, "label_encoders.pkl")

app = Flask(__name__)

# OpenAI client (مش بنستخدمه دلوقتي في أي route، بس موجود لو حبيت ترجع الشات)
try:
    client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
except Exception:
    client = None


# ================= DATA LOADING & SUMMARY =================


def load_data():
    if not os.path.exists(DATA_PATH):
        raise FileNotFoundError(f"Data file not found: {DATA_PATH}")

    df = pd.read_csv(DATA_PATH)

    # توحيد أسماء الأعمدة: استبدال المسافات بـ _
    df.columns = [c.strip().replace(" ", "_") for c in df.columns]

    # Attrition_Flag target
    if "Attrition" in df.columns:
        if df["Attrition"].dtype == object:
            df["Attrition_Flag"] = (
                df["Attrition"]
                .astype(str)
                .str.strip()
                .str.lower()
                .map({"yes": 1, "no": 0})
            )
        else:
            df["Attrition_Flag"] = df["Attrition"]
    elif "Attrition_Flag" not in df.columns:
        df["Attrition_Flag"] = 0

    return df


def compute_insights():
    df = load_data()

    result: dict[str, object] = {}

    result["rows"] = len(df)
    result["cols"] = len(df.columns)

    if "Attrition_Flag" in df.columns:
        result["attrition_rate"] = float(df["Attrition_Flag"].mean()) * 100.0
    else:
        result["attrition_rate"] = None

    if "Department" in df.columns and "Attrition_Flag" in df.columns:
        dept_attr = (
            df.groupby("Department")["Attrition_Flag"]
            .mean()
            .sort_values(ascending=False)
        )
        result["top_departments"] = [
            {"name": d, "rate": float(r) * 100.0} for d, r in dept_attr.head(5).items()
        ]
    else:
        result["top_departments"] = []

    if "Job_Role" in df.columns and "Attrition_Flag" in df.columns:
        role_attr = (
            df.groupby("Job_Role")["Attrition_Flag"]
            .mean()
            .sort_values(ascending=False)
        )
        result["top_roles"] = [
            {"name": r, "rate": float(v) * 100.0} for r, v in role_attr.head(5).items()
        ]
    else:
        result["top_roles"] = []

    if "Monthly_Income" in df.columns and "Attrition_Flag" in df.columns:
        low_q = df["Monthly_Income"].quantile(0.25)
        high_q = df["Monthly_Income"].quantile(0.75)
        low_group = df[df["Monthly_Income"] <= low_q]
        high_group = df[df["Monthly_Income"] >= high_q]
        low_attr = (
            float(low_group["Attrition_Flag"].mean()) * 100.0
            if not low_group.empty
            else None
        )
        high_attr = (
            float(high_group["Attrition_Flag"].mean()) * 100.0
            if not high_group.empty
            else None
        )

        result["income"] = {
            "avg_income": float(df["Monthly_Income"].mean()),
            "low_threshold": float(low_q),
            "high_threshold": float(high_q),
            "low_attr": low_attr,
            "high_attr": high_attr,
        }
    else:
        result["income"] = None

    if "Overtime" in df.columns and "Attrition_Flag" in df.columns:
        ot_yes = df[
            df["Overtime"].astype(str).str.lower() == "yes"
        ]["Attrition_Flag"].mean()
        ot_no = df[
            df["Overtime"].astype(str).str.lower() == "no"
        ]["Attrition_Flag"].mean()
        result["overtime"] = {
            "yes": float(ot_yes) * 100.0 if not np.isnan(ot_yes) else None,
            "no": float(ot_no) * 100.0 if not np.isnan(ot_no) else None,
        }
    else:
        result["overtime"] = None

    satisfaction_cols: list[str] = []
    for col in [
        "Job_Satisfaction",
        "Work_Life_Balance",
        "Work_Environment_Satisfaction",
        "EnvironmentSatisfaction",
    ]:
        if col in df.columns and "Attrition_Flag" in df.columns:
            satisfaction_cols.append(col)
    result["satisfaction_cols"] = satisfaction_cols

    return result


def build_data_summary_text():
    df = load_data()
    insights = compute_insights()

    lines: list[str] = []
    lines.append("Employee Attrition Dataset Summary")
    lines.append("---------------------------------")
    lines.append(f"Rows: {insights['rows']}")
    lines.append(f"Columns: {insights['cols']}")

    if insights["attrition_rate"] is not None:
        lines.append(f"Attrition rate: {insights['attrition_rate']:.1f}%")
    lines.append("")

    numeric_cols = df.select_dtypes(include="number").columns.tolist()
    if numeric_cols:
        lines.append("Numeric columns (mean / min / max):")
        for col in numeric_cols:
            s = df[col].dropna()
            if s.empty:
                continue
            mean_v = float(s.mean())
            min_v = float(s.min())
            max_v = float(s.max())
            lines.append(
                f"- {col}: mean={mean_v:.2f}, min={min_v:.2f}, max={max_v:.2f}"
            )
        lines.append("")

    cat_cols = df.select_dtypes(exclude="number").columns.tolist()
    if cat_cols:
        lines.append("Categorical columns (top values):")
        for col in cat_cols:
            vc = df[col].astype(str).value_counts().head(3)
            if vc.empty:
                continue
            lines.append(f"- {col}:")
            for v, c in vc.items():
                lines.append(f"    • {v} ({c} rows)")
        lines.append("")

    lines.append("Notes:")
    lines.append(
        "- Attrition_Flag is the target variable (1 = employee left, 0 = stayed) if available."
    )
    lines.append(
        "- Use this summary as context for any analysis or questions about the dataset."
    )

    return "\n".join(lines), insights


# ================= MODEL FOR SINGLE EMPLOYEE =================


def build_single_employee_model():
    df = load_data()

    feature_candidates = [
        "Age",
        "Department",
        "Monthly_Income",
        "Years_at_Company",
        "Distance_From_Home",
        "Job_Role",
        "Overtime",
        "Job_Level",
        "Job_Satisfaction",
        "Work_Life_Balance",
        "Work_Environment_Satisfaction",
        "Job_Involvement",
    ]
    feature_cols = [c for c in feature_candidates if c in df.columns]
    target_col = "Attrition_Flag"

    X = df[feature_cols].copy()
    y = df[target_col].copy()

    numeric_candidates = [
        "Age",
        "Monthly_Income",
        "Years_at_Company",
        "Distance_From_Home",
        "Job_Level",
        "Job_Satisfaction",
        "Work_Life_Balance",
        "Work_Environment_Satisfaction",
        "Job_Involvement",
    ]
    numeric_features = [c for c in numeric_candidates if c in feature_cols]
    categorical_features = [c for c in feature_cols if c not in numeric_features]

    numeric_transformer = SimpleImputer(strategy="median")
    categorical_transformer = Pipeline(
        steps=[
            ("imputer", SimpleImputer(strategy="most_frequent")),
            ("onehot", OneHotEncoder(handle_unknown="ignore")),
        ]
    )

    preprocessor = ColumnTransformer(
        transformers=[
            ("num", numeric_transformer, numeric_features),
            ("cat", categorical_transformer, categorical_features),
        ]
    )

    clf = RandomForestClassifier(
        n_estimators=200,
        random_state=42,
        class_weight="balanced",
    )

    model = Pipeline(
        steps=[
            ("preprocessor", preprocessor),
            ("model", clf),
        ]
    )

    model.fit(X, y)
    return model


# يتدرب مرة واحدة مع تشغيل السيرفر
single_emp_model = build_single_employee_model()


# ================= ROUTES =================


@app.route("/")
def index():
    return redirect(url_for("overview"))


@app.route("/overview")
def overview():
    df = load_data()

    total_employees = len(df)
    attrition_rate = float(df["Attrition_Flag"].mean()) * 100

    if "Department" in df.columns:
        dept_stats = (
            df.groupby("Department")["Attrition_Flag"]
            .mean()
            .reset_index(name="AttritionRate")
            .to_dict(orient="records")
        )
    else:
        dept_stats = []

    if "Job_Level" in df.columns:
        level_stats = (
            df.groupby("Job_Level")["Attrition_Flag"]
            .mean()
            .reset_index(name="AttritionRate")
            .to_dict(orient="records")
        )
    else:
        level_stats = []

    return render_template(
        "overview.html",
        total_employees=total_employees,
        attrition_rate=attrition_rate,
        dept_stats=dept_stats,
        level_stats=level_stats,
    )


@app.route("/training", methods=["GET", "POST"])
def training():
    df = load_data()

    departments = (
        sorted(df["Department"].dropna().unique())
        if "Department" in df.columns
        else []
    )
    job_roles = (
        sorted(df["Job_Role"].dropna().unique()) if "Job_Role" in df.columns else []
    )
    overtime_values = (
        sorted(df["Overtime"].dropna().unique())
        if "Overtime" in df.columns
        else ["Yes", "No"]
    )

    prediction = None
    summary = None
    explanations: list[str] = []
    actions: list[str] = []

    if request.method == "POST":
        form = request.form

        age_val = int(form.get("Age", 30))
        dept_val = form.get("Department", departments[0] if departments else "")
        income_val = float(form.get("Monthly_Income", 5000))
        years_val = int(form.get("Years_at_Company", 3))
        dist_val = int(form.get("Distance_From_Home", 10))
        role_val = form.get("Job_Role", job_roles[0] if job_roles else "")
        overtime_val = form.get("Overtime", "Yes")
        joblevel_val = int(form.get("Job_Level", 1))
        jobsat_val = int(form.get("Job_Satisfaction", 1))
        wlb_val = int(form.get("Work_Life_Balance", 1))
        envsat_val = int(form.get("Work_Environment_Satisfaction", 1))
        jobinv_val = int(form.get("Job_Involvement", 1))

        row: dict[str, object] = {}

        if "Age" in df.columns:
            row["Age"] = age_val
        if "Department" in df.columns:
            row["Department"] = dept_val
        if "Monthly_Income" in df.columns:
            row["Monthly_Income"] = income_val
        if "Years_at_Company" in df.columns:
            row["Years_at_Company"] = years_val
        if "Distance_From_Home" in df.columns:
            row["Distance_From_Home"] = dist_val
        if "Job_Role" in df.columns:
            row["Job_Role"] = role_val
        if "Overtime" in df.columns:
            row["Overtime"] = overtime_val
        if "Job_Level" in df.columns:
            row["Job_Level"] = joblevel_val
        if "Job_Satisfaction" in df.columns:
            row["Job_Satisfaction"] = jobsat_val
        if "Work_Life_Balance" in df.columns:
            row["Work_Life_Balance"] = wlb_val
        if "Work_Environment_Satisfaction" in df.columns:
            row["Work_Environment_Satisfaction"] = envsat_val
        if "Job_Involvement" in df.columns:
            row["Job_Involvement"] = jobinv_val

        X_single = pd.DataFrame([row])

        prob = single_emp_model.predict_proba(X_single)[0][1]
        label = int(single_emp_model.predict(X_single)[0])

        percent = round(prob * 100, 1)
        if prob > 0.6:
            risk = "High"
        elif prob > 0.3:
            risk = "Medium"
        else:
            risk = "Low"

        prediction = f"{label} ({percent}%)"
        summary = f"Attrition risk is {risk} with estimated probability {percent}%."

        explanations.append(
            f"The model predicts a {risk.upper()} attrition risk that should be monitored."
        )

        if jobsat_val <= 2:
            explanations.append(
                "Job satisfaction score is low, which may increase the chance of leaving."
            )
        else:
            explanations.append("Job satisfaction score is acceptable.")

        if wlb_val <= 2:
            explanations.append(
                "Work–life balance is poor; workload or schedule may be stressing the employee."
            )
        else:
            explanations.append("Work–life balance seems reasonable.")

        if envsat_val <= 2:
            explanations.append(
                "Work environment satisfaction is low; the employee may not feel comfortable in the current environment."
            )
        else:
            explanations.append("Work environment satisfaction is acceptable.")

        if jobinv_val <= 2:
            explanations.append(
                "Job involvement is low, indicating limited engagement with day-to-day tasks."
            )
        else:
            explanations.append("Job involvement level is acceptable.")

        if overtime_val.lower() == "yes":
            explanations.append(
                "The employee is working overtime, which can contribute to fatigue or burnout if it continues."
            )

        actions = [
            "Schedule a one-to-one meeting with the employee to discuss workload, expectations, and career plans.",
            "Review compensation, benefits, and recognition compared to peers in similar roles.",
            "Offer options to improve work–life balance (flexible hours, remote days, or redistribution of tasks).",
            "Provide clear development opportunities such as training, mentoring, or promotions when possible.",
            "Monitor this employee over the next period and review key risk signals regularly.",
        ]

    return render_template(
        "training.html",
        departments=departments,
        job_roles=job_roles,
        prediction=prediction,
        summary=summary,
        explanations=explanations,
        actions=actions,
    )


@app.route("/data_summary")
def data_summary():
    try:
        summary_text, insights = build_data_summary_text()
    except Exception as e:
        summary_text = f"Error while reading dataset: {e}"
        insights = None
    return render_template(
        "data_summary.html",
        summary_text=summary_text,
        insights=insights,
    )


@app.route("/report")
def report():
    try:
        summary_text, insights = build_data_summary_text()
    except Exception as e:
        summary_text = f"Error while reading dataset: {e}"
        insights = None

    generated_at = datetime.now().strftime("%Y-%m-%d %H:%M")

    return render_template(
        "report.html",
        summary_text=summary_text,
        insights=insights,
        generated_at=generated_at,
    )


# Attach Dash dashboard on /dashboard/
init_dashboard(app)


if __name__ == "__main__":
    app.run(debug=True)
