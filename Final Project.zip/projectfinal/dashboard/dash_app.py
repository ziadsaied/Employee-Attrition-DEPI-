import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from dash import Dash, dcc, html, Input, Output
import dash_bootstrap_components as dbc
from plotly.subplots import make_subplots

try:
    df = pd.read_csv("cleaned_data.csv")
except FileNotFoundError:
    print("Error: 'cleaned_data.csv' not found.")
    df = pd.DataFrame({
        'Age': [30, 40, 50], 'Monthly_Income': [0.5, 0.8, 0.2], 'Attrition': [1, 0, 1],
        'Hourly_Rate': [50, 60, 70], 'Average_Hours_Worked_Per_Week': [40, 45, 50],
        'Department_HR': [1, 0, 0], 'Department_IT': [0, 1, 0], 'Department_Sales': [0, 0, 1],
        'Job_Role_Manager': [1, 0, 0], 'Job_Satisfaction': [5, 2, 1], 'Years_at_Company': [5, 1, 10],
        'Years_Since_Last_Promotion': [0, 5, 1], 'Work_Life_Balance': [3, 2, 4]
    })

df['Attrition'] = df['Attrition'].astype(str).str.lower().str.strip()
df['Attrition'] = df['Attrition'].replace({
    '1': 'yes', '0': 'no', 'true': 'yes', 'false': 'no',
    'left': 'yes', 'stayed': 'no', 'y': 'yes', 'n': 'no'
})
df['Attrition'] = df['Attrition'].map({'yes': 'Yes', 'no': 'No'})
df = df.dropna(subset=['Attrition'])

def get_category(df, prefix, new_col_name):
    cols = [c for c in df.columns if c.startswith(prefix)]
    if cols:
        df[new_col_name] = df[cols].idxmax(axis=1).str.replace(prefix, '')
    else:
        df[new_col_name] = "Other"

get_category(df, "Department_", "Department")
get_category(df, "Job_Role_", "JobRole")

if 'Hourly_Rate' in df.columns and 'Average_Hours_Worked_Per_Week' in df.columns:
    df['Monthly_Income_Display'] = df['Hourly_Rate'] * df['Average_Hours_Worked_Per_Week'] * 52 / 12
else:
    df['Monthly_Income_Display'] = df['Monthly_Income']

TOTAL_EMPLOYEES = len(df)
ATTRITION_RATE = df['Attrition'].value_counts(normalize=True).get('Yes', 0) * 100
AVG_AGE = round(df['Age'].mean(), 1)
AVG_MONTHLY_INCOME = df['Monthly_Income_Display'].mean()

MIN_AGE, MAX_AGE = df['Age'].min(), df['Age'].max()
MIN_INCOME, MAX_INCOME = int(df['Monthly_Income_Display'].min()), int(df['Monthly_Income_Display'].max())

income_step = 5000 if MAX_INCOME > 20000 else 1000
income_marks = {i: f"${i/1000:,.0f}K" for i in range(MIN_INCOME, MAX_INCOME + 1, income_step)}
income_marks[MAX_INCOME] = f"${MAX_INCOME/1000:,.0f}K"

# ------------------------------  DASH APP FACTORY  ------------------------------

dash = None


def init_dashboard(server):
    global dash

    dash = Dash(
        server=server,
        name="Dashboard",
        external_stylesheets=[dbc.themes.CERULEAN],
        routes_pathname_prefix="/dashboard/",
        requests_pathname_prefix="/dashboard/"
    )

    def create_kpi_card(title, value, unit="", color="primary"):
        return dbc.Card(
            [
                dbc.CardHeader(title, className="text-white font-bold bg-primary"),
                dbc.CardBody([
                    html.H3(f"{value}{unit}", className=f"text-{color} font-bold text-2xl")
                ])
            ],
            className="text-center shadow-lg", style={"minHeight": "100%"}
        )

    dash.layout = dbc.Container([
        html.H1("📊 Advanced Employee Attrition Dashboard", className="my-4 text-center text-primary"),
        html.Hr(),

        dbc.Row([
            dbc.Col(create_kpi_card("Total Employees", TOTAL_EMPLOYEES, color="info"), md=3),
            dbc.Col(create_kpi_card("Attrition Rate", f"{ATTRITION_RATE:.2f}", "%", color="danger"), md=3),
            dbc.Col(create_kpi_card("Average Age", AVG_AGE, " yrs", color="warning"), md=3),
            dbc.Col(create_kpi_card("Avg. Monthly Income (Est.)", f"${AVG_MONTHLY_INCOME:,.0f}", color="success"), md=3),
        ], className="mb-5"),

        dbc.Row([
            dbc.Col(html.Label("Group By:")),
            dbc.Col(
                dcc.Dropdown(
                    id="group-dropdown",
                    options=[
                        {"label": "Department", "value": "Department"},
                        {"label": "Job Role", "value": "JobRole"},
                        {"label": "Gender", "value": "Gender"},
                        {"label": "Work Life Balance", "value": "Work_Life_Balance"},
                        {"label": "Performance Rating", "value": "Performance_Rating"}
                    ],
                    value="Department",
                    clearable=False
                ),
                md=4
            ),

            dbc.Col(html.Label("Attrition Filter:")),
            dbc.Col(
                dcc.Checklist(
                    id="attrition-checklist",
                    options=[{"label": " Stayed", "value": "No"}, {"label": " Left", "value": "Yes"}],
                    value=["No", "Yes"],
                    inline=True
                ),
                md=4
            )
        ], className="mb-4 border p-3 bg-light rounded"),

        dbc.Row([
            dbc.Col(html.Label("Filter by Age:")),
            dbc.Col(
                dcc.RangeSlider(
                    id="age-slider",
                    min=MIN_AGE, max=MAX_AGE,
                    value=[MIN_AGE, MAX_AGE],
                    step=1,
                    marks={i: str(i) for i in range(int(MIN_AGE), int(MAX_AGE) + 1, 5)},
                    tooltip={"always_visible": True}
                ),
                md=8
            )
        ], className="mb-4 border p-3 bg-light rounded"),

        dbc.Row([
            dbc.Col(html.Label("Filter by Monthly Income:")),
            dbc.Col(
                dcc.RangeSlider(
                    id="income-slider",
                    min=MIN_INCOME, max=MAX_INCOME,
                    value=[MIN_INCOME, MAX_INCOME],
                    step=100,
                    marks=income_marks,
                    tooltip={"always_visible": True}
                ),
                md=8
            )
        ], className="mb-4 border p-3 bg-light rounded"),

        dcc.Tabs([
            dcc.Tab(label="Core Breakdown", children=[
                dbc.Row([
                    dbc.Col(dcc.Graph(id="bar-chart"), lg=6),
                    dbc.Col(dcc.Graph(id="income-comparison-chart"), lg=6)
                ])
            ]),

            dcc.Tab(label="Tenure & Satisfaction", children=[
                dbc.Row([
                    dbc.Col(dcc.Graph(id="tenure-trend-chart"), lg=6),
                    dbc.Col(dcc.Graph(id="satisfaction-v-attrition"), lg=6),
                ])
            ]),

            dcc.Tab(label="Correlation & Deep Dive", children=[
                dbc.Row([
                    dbc.Col(dcc.Graph(id="heatmap-chart"), lg=12)
                ])
            ])
        ])
    ], fluid=True)

    @dash.callback(
        Output("bar-chart", "figure"),
        Output("income-comparison-chart", "figure"),
        Output("tenure-trend-chart", "figure"),
        Output("satisfaction-v-attrition", "figure"),
        Output("heatmap-chart", "figure"),
        [
            Input("group-dropdown", "value"),
            Input("attrition-checklist", "value"),
            Input("age-slider", "value"),
            Input("income-slider", "value")
        ]
    )
    def update_dashboard(group_by, attrition_filter, age_range, income_range):
        dff = df[df["Attrition"].isin(attrition_filter)].copy()
        dff = dff[(dff["Age"] >= age_range[0]) & (dff["Age"] <= age_range[1])]
        dff = dff[
            (dff["Monthly_Income_Display"] >= income_range[0]) &
            (dff["Monthly_Income_Display"] <= income_range[1])
        ]

        if group_by not in dff.columns:
            group_by = "Department"

        bar_chart = px.histogram(
            dff, x=group_by, color="Attrition", barmode="group",
            template="plotly_white"
        )

        income_chart = px.box(
            dff, x="Attrition", y="Monthly_Income_Display", color="Attrition",
            template="plotly_white"
        )

        if not dff.empty:
            tenure_df = (
                dff.groupby("Years_at_Company")["Attrition"]
                .apply(lambda x: (x == "Yes").mean() * 100)
                .reset_index()
            )
        else:
            tenure_df = pd.DataFrame({"Years_at_Company": [], "Attrition_Rate": []})

        tenure_chart = px.bar(
            tenure_df, x="Years_at_Company", y="Attrition",
            template="plotly_white"
        )

        if "Job_Satisfaction" in dff.columns and not dff.empty:
            sat = (
                dff.groupby("Job_Satisfaction")["Attrition"]
                .apply(lambda x: (x == "Yes").mean() * 100)
                .reset_index()
            )
            sat_chart = px.bar(sat, x="Job_Satisfaction", y="Attrition", template="plotly_white")
        else:
            sat_chart = go.Figure()

        if not dff.empty:
            corr = dff.select_dtypes(include=['float64', 'int64']).corr()
            heatmap = px.imshow(corr, text_auto=".2f", template="plotly_white")
        else:
            heatmap = go.Figure()

        return bar_chart, income_chart, tenure_chart, sat_chart, heatmap

    return dash