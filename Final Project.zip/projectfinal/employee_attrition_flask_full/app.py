﻿from flask import Flask, render_template, request, redirect, url_for
import pandas as pd
import os

app = Flask(__name__)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_PATH = os.path.join(BASE_DIR, "data", "employee_attrition_dataset.csv")


def load_data():
    if not os.path.exists(DATA_PATH):
        raise FileNotFoundError(f"Data file not found: {DATA_PATH}")
    df = pd.read_csv(DATA_PATH)
    df.columns = df.columns.str.strip().str.replace(" ", "_")
    return df


@app.route("/")
def home():
    return redirect(url_for("overview"))


@app.route("/overview")
def overview():
    df = load_data()
    total = len(df)

    if "Attrition" in df.columns:
        attrition_rate = round((df["Attrition"] == "Yes").mean() * 100, 2)
    else:
        attrition_rate = 0

    departments = []
    if "Department" in df.columns:
        d = df["Department"].value_counts().reset_index()
        d.columns = ["Department", "Count"]
        departments = d.to_dict(orient="records")

    return render_template(
        "overview.html",
        total=total,
        attrition_rate=attrition_rate,
        departments=departments
    )


@app.route("/visualizations")
def visualizations():
    df = load_data()
    charts = {}

    if "Attrition" in df.columns:
        charts["Attrition"] = df["Attrition"].value_counts().to_dict()

    if "Department" in df.columns:
        charts["Department"] = df["Department"].value_counts().to_dict()

    if "Job_Level" in df.columns:
        charts["Job Level"] = df["Job_Level"].value_counts().to_dict()

    if "Work_Life_Balance" in df.columns:
        charts["Work Life Balance"] = df["Work_Life_Balance"].value_counts().to_dict()

    return render_template("visualizations.html", charts=charts)


@app.route("/training")
def training():
    return render_template("training.html")


@app.route("/assistant", methods=["GET", "POST"])
@app.route("/chat", methods=["GET", "POST"])
def assistant():
    reply = None
    user_input = None

    if request.method == "POST":
        user_input = request.form.get("message", "")
        if user_input.strip():
            reply = (
                "أنا مساعد البيانات داخل المشروع. لسه مش متوصل بـ OpenAI API.\n"
                f"سؤالك كان: {user_input}"
            )

    return render_template("assistant.html", reply=reply, user_input=user_input)


@app.route("/dashboard")
def dashboard():
    df = load_data()

    total = len(df)
    if "Attrition" in df.columns:
        attrition_rate = round((df["Attrition"] == "Yes").mean() * 100, 2)
    else:
        attrition_rate = 0

    return render_template(
        "dashboard.html",
        total=total,
        attrition_rate=attrition_rate
    )


if __name__ == "__main__":
    app.run(debug=True)
